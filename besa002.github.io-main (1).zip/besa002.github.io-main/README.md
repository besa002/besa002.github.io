A simple website because my ego is way too high to text first. 
